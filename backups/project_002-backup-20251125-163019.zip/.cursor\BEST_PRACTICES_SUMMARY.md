# Краткое резюме: Best Practices для Cursor IDE

Анализ файла `compass_artifact_wf-1e8e192b-501d-47ec-980a-cd4cdcb6009c_text_markdown.md` и сравнение с текущим состоянием проекта.

---

## ✅ Что УЖЕ есть в проекте

### 1. Система правил `.cursor/rules/` (Level 2-3)

- ✅ `.cursor/index.mdc` — Level 2 правила с `alwaysApply: true`
- ✅ `.cursor/rules/agents/` — специализированные агенты (backend, frontend, testing)
- ✅ `.cursor/rules/workflows/` — воркфлоу (feature-development, code-review)
- ✅ Трехуровневая архитектура правил реализована

### 2. MCP серверы (настроены в `mcp.json`)

- ✅ **sequential-thinking** — структурирование задач
- ✅ **context7** — документация библиотек (требует API key)
- ✅ **filesystem** — доступ к `src/` и `public/` (read-only)
- ✅ **memory** — персистентная память (knowledge graph)
- ✅ **github** — интеграция с GitHub API (требует API key)
- ✅ **browser-tools** — инструменты для браузера
- ✅ **prompt-engineer** — оптимизация промптов через Claude (требует ANTHROPIC_API_KEY)

### 3. Конфигурация проекта

- ✅ **Vite** — настроен с алиасами (`@`, `@components`, `@store`, и т.д.)
- ✅ **Vite** — manual chunks для оптимизации бандла (react-vendor, icons-vendor, tone-vendor, date-vendor)
- ✅ **Vite** — HMR overlay включен, sourcemap для production
- ✅ **package.json** — зависимости установлены (React 18.3, Zustand 5.0, Tailwind 3.4, Vitest 4.0)
- ✅ **Vitest** — настроен с `@testing-library/react`, `jsdom`

### 4. Безопасность

- ✅ `.gitignore` — исключает `.cursor/mcp.json` (содержит секреты)
- ✅ `.cursorignore` — исключает `node_modules`, `build`, `dist`, `coverage`
- ✅ Filesystem MCP ограничен только `src/` и `public/`

---

## 🔧 Что можно настроить/добавить

### Критически важно (сделать сейчас)

#### 1. ESLint конфигурация

**Статус:** ✅ **ВЫПОЛНЕНО**

**Что создано:**

- ✅ `eslint.config.js` — ESLint 9+ flat config
- ✅ Правила для React Hooks (`react-hooks/exhaustive-deps`, `react-hooks/rules-of-hooks`)
- ✅ Правила для JavaScript/JSX
- ✅ Игнорирование служебных папок (dist, build, node_modules, backups)

**Файлы:**

- `eslint.config.js` — основная конфигурация
- `package.json` — добавлены скрипты `lint` и `lint:fix`

**Следующий шаг:** Установить зависимости `npm install` (если еще не установлены)

---

#### 2. Prettier конфигурация

**Статус:** ✅ **ВЫПОЛНЕНО**

**Что создано:**

- ✅ `.prettierrc` — конфигурация Prettier
- ✅ `.prettierignore` — исключения для форматирования
- ✅ `eslint-config-prettier` добавлен в `package.json` для предотвращения конфликтов

**Файлы:**

- `.prettierrc` — настройки форматирования
- `.prettierignore` — исключения
- `package.json` — добавлены скрипты `format` и `format:check`

**Следующий шаг:**

- Установить зависимости `npm install`
- Настроить "Format On Save" в Cursor (см. `docs/guides/CURSOR_EXTENSIONS_SETUP.md`)

---

#### 3. Дополнительные правила в `.cursor/rules/`

**Статус:** ✅ **ВЫПОЛНЕНО**

**Что создано:**

- ✅ `000-core.mdc` — базовые принципы стека (React 18.3, Zustand 5.0, Tailwind 3.4)
- ✅ `react-patterns.mdc` — правила React с `globs: ["**/*.jsx", "**/*.tsx"]`
  - Rules of Hooks (хуки только на верхнем уровне)
  - Обязательные dependency arrays
  - Запрет на index как key
  - Очистка в useEffect
- ✅ `zustand-stores.mdc` — правила Zustand с `globs: ["**/store/**/*.js", "**/stores/**/*.js"]`
  - Атомарные селекторы (никогда не экспортировать стор напрямую)
  - Разделение actions от state через namespace
  - Множественные маленькие сторы по доменам
- ✅ `recharts-patterns.mdc` — специфичные правила для Recharts
  - ResponsiveContainer обязателен
  - useMemo для data transformations
  - Лимит 100-200 точек для line charts
- ✅ `framer-motion-patterns.mdc` — специфичные правила для Framer Motion
  - Только transform properties (x, y, scale, rotate)
  - willChange CSS property обязателен
  - AnimatePresence для exit animations

**Файлы:**

- `.cursor/rules/000-core.mdc`
- `.cursor/rules/react-patterns.mdc`
- `.cursor/rules/zustand-stores.mdc`
- `.cursor/rules/recharts-patterns.mdc`
- `.cursor/rules/framer-motion-patterns.mdc`

---

#### 4. Husky + lint-staged

**Статус:** ✅ **ВЫПОЛНЕНО**

**Что создано:**

- ✅ `.lintstagedrc.js` — конфигурация lint-staged
- ✅ `.husky/pre-commit` — pre-commit hook
- ✅ `package.json` — добавлены зависимости `husky` и `lint-staged`
- ✅ Скрипт `prepare` для автоматической инициализации Husky

**Файлы:**

- `.lintstagedrc.js` — правила для lint-staged
- `.husky/pre-commit` — hook для pre-commit
- `package.json` — зависимости и скрипты

**Следующий шаг:**

- Установить зависимости `npm install`
- Husky автоматически инициализируется при `npm install` (через скрипт `prepare`)

**Примечание:** Husky требует git репозиторий. Если проект не в git, инициализируйте: `git init`

---

#### 5. tsconfig.json синхронизация

**Статус:** ✅ **ВЫПОЛНЕНО**

**Что создано:**

- ✅ `tsconfig.json` — основная конфигурация TypeScript
- ✅ `tsconfig.node.json` — конфигурация для Node.js файлов (vite.config.js, vitest.config.js)
- ✅ `compilerOptions.paths` синхронизированы с Vite aliases

**Файлы:**

- `tsconfig.json` — основная конфигурация с paths
- `tsconfig.node.json` — конфигурация для конфигурационных файлов

**Paths синхронизированы:**

- `@/*` → `./src/*`
- `@components/*` → `./src/components/*`
- `@store/*` → `./src/store/*`
- `@hooks/*` → `./src/hooks/*`
- `@utils/*` → `./src/utils/*`
- `@constants/*` → `./src/constants/*`
- `@styles/*` → `./src/styles/*`

### Важно (можно добавить позже)

#### 6. Расширения Cursor (установить вручную)

**Статус:** ✅ **ДОКУМЕНТАЦИЯ СОЗДАНА**

**Документация:** `docs/guides/CURSOR_EXTENSIONS_SETUP.md`

**Расширения для установки:**

- ✅ **ESLint** — расширение для Cursor (инструкция в документации)
- ✅ **Prettier** — расширение для Cursor (инструкция в документации)
- ✅ **Tailwind CSS IntelliSense** — autocomplete для Tailwind классов (инструкция в документации)
- ✅ **Error Lens** — показывает ошибки inline в коде (инструкция в документации)
- ✅ **SpecStory** — автоматическое сохранение истории чатов в `.specstory/history/` (инструкция в документации)
- ✅ **Cursor Stats** — мониторинг usage statistics в status bar (инструкция в документации)

**Следующий шаг:** Откройте `docs/guides/CURSOR_EXTENSIONS_SETUP.md` и следуйте инструкциям по установке расширений

---

#### 7. Дополнительные MCP серверы

**Статус:** ⚠️ Опционально (можно добавить позже)

**Серверы для рассмотрения:**

- **Langfuse Prompt Management** — версионирование и управление промптами (требует API key)
- **Storybook MCP** — документация компонентов (если используется Storybook)
- **Playwright MCP** — E2E тестирование (Microsoft)
- **Nx Console MCP** — только если используется Nx monorepo

---

#### 8. Vitest UI mode

**Статус:** ✅ **ВЫПОЛНЕНО**

**Что создано:**

- ✅ `vitest.config.js` обновлен с UI mode (`ui: true`)
- ✅ Coverage reporting настроен (цель 80%+)
- ✅ Пороги покрытия установлены (lines, functions, branches, statements: 80%)
- ✅ Алиасы синхронизированы с Vite и tsconfig.json

**Файлы:**

- `vitest.config.js` — обновленная конфигурация

**Использование:**

```bash
npm run test:ui  # Запуск UI mode
npm run test:coverage  # Запуск с coverage
```

---

#### 9. Cursor Stats расширение

**Статус:** ✅ **ДОКУМЕНТАЦИЯ СОЗДАНА**

**Документация:** `docs/guides/CURSOR_EXTENSIONS_SETUP.md` (раздел "Cursor Stats")

**Что дает:**

- Мониторинг usage statistics в status bar
- Отслеживание близости к лимиту Claude
- Планирование сложных задач на периоды с доступным Claude

**Следующий шаг:** Установите расширение через Cursor Extensions (см. документацию)

---

## 🔑 Что работает ТОЛЬКО с API key

### Требуют API ключи (уже настроены, но нужны ключи)

#### 1. **context7** MCP

- **Требует:** Context7 API key (`ctx7sk-...`)
- **Статус:** ✅ Настроен в `mcp.json`
- **Проблема:** Не видно полный API key в dashboard
- **Решение:**
  - Использовать переменную окружения `${CONTEXT7_API_KEY}`
  - Или скопировать ключ через DevTools (Network tab при создании ключа)

#### 2. **github** MCP

- **Требует:** GitHub Personal Access Token
- **Статус:** ✅ Настроен в `mcp.json`
- **Что дает:** 100+ инструментов GitHub API (репозитории, PR, issues, code search)

#### 3. **prompt-engineer** MCP

- **Требует:** `ANTHROPIC_API_KEY` (Claude 3 Sonnet)
- **Статус:** ✅ Настроен в `mcp.json`
- **Что дает:** Оптимизация промптов через Claude 3 Sonnet (15-30% улучшение качества)
- **Стоимость:** Списываются токены с Anthropic аккаунта

### Требуют API ключи (можно добавить)

#### 4. **Langfuse Prompt Management**

- **Требует:** Langfuse Public Key и Secret Key
- **Статус:** ✅ **НАСТРОЕНО** (требуется добавить Secret Key в переменные окружения)
- **Что дает:** Командная работа над промптами, версионирование, оценка
- **Для zero-кодеров:** Библиотека проверенных промптов
- **Документация:** `docs/mcp/LANGFUSE_SETUP.md`
- **API Keys:**
  - ✅ Public Key: `pk-lf-131807d7-2b95-41bb-9812-1a685eda55d2` (настроен)
  - ⚠️ Secret Key: требуется добавить в переменные окружения (`LANGFUSE_SECRET_KEY`)

---

## 📊 Приоритеты внедрения

### ✅ День 1 (критично) — ВЫПОЛНЕНО

1. ✅ ESLint конфигурация — **ГОТОВО**
2. ✅ Prettier конфигурация — **ГОТОВО**
3. ✅ tsconfig.json с синхронизацией paths — **ГОТОВО**
4. ✅ Документация для расширений Cursor — **ГОТОВО** (`docs/guides/CURSOR_EXTENSIONS_SETUP.md`)

**Следующий шаг:** Установите расширения Cursor вручную (см. документацию)

### ✅ День 2 (важно) — ВЫПОЛНЕНО

1. ✅ Дополнительные правила в `.cursor/rules/` — **ГОТОВО**:
   - ✅ `000-core.mdc`
   - ✅ `react-patterns.mdc`
   - ✅ `zustand-stores.mdc`
   - ✅ `recharts-patterns.mdc`
   - ✅ `framer-motion-patterns.mdc`
2. ✅ Husky + lint-staged — **ГОТОВО**
3. ✅ Vitest конфигурация с UI mode — **ГОТОВО**

**Следующий шаг:** Установите зависимости `npm install` и инициализируйте git репозиторий (если еще не сделано)

### ✅ Неделя 1-2 (опционально) — ЧАСТИЧНО ВЫПОЛНЕНО

1. ⚠️ SpecStory расширение — **ДОКУМЕНТАЦИЯ ГОТОВА**, требуется установка вручную
2. ⚠️ Cursor Stats расширение — **ДОКУМЕНТАЦИЯ ГОТОВА**, требуется установка вручную
3. ⚠️ Дополнительные MCP серверы (Storybook, Playwright) — опционально
4. ✅ **Langfuse Prompt Management** — **НАСТРОЕНО** (требуется добавить Secret Key)
   - ✅ Пакет установлен: `@meltstudio/langfuse-mcp-server`
   - ✅ Конфигурация добавлена в `C:\Users\kissl\.cursor\mcp.json`
   - ✅ Документация создана: `docs/mcp/LANGFUSE_SETUP.md`
   - ⚠️ **Следующий шаг:** Добавить `LANGFUSE_SECRET_KEY` в переменные окружения (см. документацию)

---

## 🎯 Ожидаемый результат

После внедрения всех компонентов:

- **Снижение ошибок на 60-80%** (с 20-40 ошибок на 100 строк до <5 ошибок)
- **Автоматическая проверка качества** через ESLint + Prettier + Husky
- **Улучшение промптов на 15-30%** через Prompt Engineer MCP
- **Структурированный контекст** через `.cursor/rules/` для fallback моделей
- **Персистентная память** через Memory MCP для накопления контекста

---

## 📝 Быстрая справка

### Команды для установки зависимостей

```bash
# Установить все зависимости (включая новые: prettier, eslint-config-prettier, husky, lint-staged)
npm install

# Если проект не в git, инициализируйте репозиторий для Husky
git init

# Проверка ESLint
npm run lint

# Автоисправление ESLint ошибок
npm run lint:fix

# Форматирование кода
npm run format

# Проверка форматирования
npm run format:check

# Запуск тестов в UI mode
npm run test:ui

# Запуск тестов с coverage
npm run test:coverage
```

**Примечание:** Все конфигурационные файлы уже созданы. Просто выполните `npm install` для установки зависимостей.

### Переменные окружения для MCP

```bash
# Windows PowerShell
$env:ANTHROPIC_API_KEY="sk-ant-your-key"
$env:CONTEXT7_API_KEY="ctx7sk-your-key"
$env:GITHUB_PERSONAL_ACCESS_TOKEN="ghp_your-token"
$env:LANGFUSE_SECRET_KEY="sk-lf-your-secret-key"  # ⚠️ Требуется для Langfuse
```

**Примечание:** `LANGFUSE_PUBLIC_KEY` уже настроен в `mcp.json` напрямую.

---

**Последнее обновление:** 2025-01-27
**Источник:** `docs/BEST_PRACTICS/compass_artifact_wf-1e8e192b-501d-47ec-980a-cd4cdcb6009c_text_markdown.md`
