'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import confetti from 'canvas-confetti';
import toast from 'react-hot-toast';
import { Skeleton } from '@/components/Skeleton';
import AccordionButton from '@/components/AccordionButton';
import AnimatedCounter from '@/components/AnimatedCounter';

interface Effect {
  id: number;
  category: string;
  categoryEmoji: string;
  categoryName: string;
  title: string;
  question: string;
  variantA: string;
  variantB: string;
  votesA: number;
  votesB: number;
  currentState: string;
  sourceLink: string;
  dateAdded: string;
  percentA: number;
  percentB: number;
  totalVotes: number;
  interpretations?: {
    scientific: string;
    scientificTheory?: string;
    scientificSource?: string;
    community: string;
    communitySource?: string;
  };
}

// Маппинг источников на URL
const getSourceUrl = (source: string): string => {
  const sourceMap: Record<string, string> = {
    'Simply Psychology': 'https://www.simplypsychology.org/false-memory.html',
    'Psychology Today': 'https://www.psychologytoday.com/us/basics/memory',
    'Medical News Today': 'https://www.medicalnewstoday.com/articles/326582',
    'Brain Bridge Lab (UChicago)': 'https://bridge.uchicago.edu/news/pikachus-tail-how-false-memories-are-generated',
    'Cognitive Psychology Review': 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4183265/',
    'Journal of Memory and Language': 'https://www.journals.elsevier.com/journal-of-memory-and-language',
    'Memory & Cognition Journal': 'https://link.springer.com/journal/13421',
    'Journal of Phonetics': 'https://www.journals.elsevier.com/journal-of-phonetics',
    'Cognitive Science': 'https://onlinelibrary.wiley.com/journal/15516709',
    'Disney Archives Research': 'https://d23.com/disney-archives/',
    'Memory Research': 'https://www.nature.com/subjects/memory',
    'Linguistics Today': 'https://www.journals.elsevier.com/lingua',
    'Russian Linguistics': 'https://link.springer.com/journal/11185',
    'Visual Perception Research': 'https://www.nature.com/subjects/visual-perception',
    'r/MandelaEffect': 'https://www.reddit.com/r/MandelaEffect/',
    'r/Retconned': 'https://www.reddit.com/r/Retconned/',
  };
  
  return sourceMap[source] || '#';
};

export default function EffectPage() {
  const params = useParams();
  const router = useRouter();
  const id = parseInt(params.id as string);
  const [effect, setEffect] = useState<Effect | null>(null);
  const [allEffects, setAllEffects] = useState<Effect[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedVariant, setSelectedVariant] = useState<'A' | 'B' | null>(null);
  const [hasVoted, setHasVoted] = useState(false);
  const [isAccordionOpen, setIsAccordionOpen] = useState(false);
  const [isVoting, setIsVoting] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [progressA, setProgressA] = useState(0);
  const [progressB, setProgressB] = useState(0);
  const [showInterpretations, setShowInterpretations] = useState(false);
  const [votingVariant, setVotingVariant] = useState<'A' | 'B' | null>(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        
        // Загружаем все эффекты для навигации
        const allEffectsResponse = await fetch('/api/effects');
        if (allEffectsResponse.ok) {
          const allData = await allEffectsResponse.json();
          setAllEffects(allData);
        }

        // Загружаем текущий эффект
        const response = await fetch(`/api/effect/${id}`);
        if (response.ok) {
          const data = await response.json();
          setEffect(data);
          
          // Проверяем localStorage
          const votedKey = `voted_effect_${data.id}`;
          const votedStr = localStorage.getItem(votedKey);
          if (votedStr) {
            try {
              const voteData = JSON.parse(votedStr);
              const voted = typeof voteData === 'string' ? voteData : voteData.variant;
              if (voted === 'A' || voted === 'B') {
                setSelectedVariant(voted);
                setHasVoted(true);
                setShowResults(true);
                // Устанавливаем финальные значения прогресс-баров
                setProgressA(data.percentA);
                setProgressB(data.percentB);
              } else {
                // Некорректные данные - сбрасываем
                setHasVoted(false);
                setSelectedVariant(null);
                setShowResults(false);
              }
            } catch {
              // Fallback для старого формата
              if (votedStr === 'A' || votedStr === 'B') {
                setSelectedVariant(votedStr);
                setHasVoted(true);
                setShowResults(true);
                setProgressA(data.percentA);
                setProgressB(data.percentB);
              } else {
                // Некорректные данные - сбрасываем
                setHasVoted(false);
                setSelectedVariant(null);
                setShowResults(false);
              }
            }
          } else {
            // Нет голоса - сбрасываем состояние
            setHasVoted(false);
            setSelectedVariant(null);
            setShowResults(false);
          }
        } else if (response.status === 404) {
          router.push('/catalog');
        }
      } catch (error) {
        console.error('Ошибка загрузки эффекта:', error);
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      loadData();
    }
  }, [id, router]);

  const handleVote = async (variant: 'A' | 'B') => {
    if (!effect || hasVoted || isVoting) return;

    setVotingVariant(variant);
    setIsVoting(true);

    try {
      const response = await fetch('/api/vote', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          effectId: effect.id,
          variant,
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        // Сохраняем в localStorage с timestamp и effectTitle
        const votedKey = `voted_effect_${effect.id}`;
        const voteData = {
          variant,
          timestamp: Date.now(),
          effectTitle: effect.title,
        };
        localStorage.setItem(votedKey, JSON.stringify(voteData));
        
        // Отправляем событие для обновления каталога
        window.dispatchEvent(new Event('voteUpdated'));
        
        // Обновляем состояние с данными из ответа
        setEffect({
          ...effect,
          ...data.effect,
        });
        
        setSelectedVariant(variant);
        setHasVoted(true);

        // Запускаем конфетти с цветом в зависимости от варианта
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: variant === 'A' ? ['#3b82f6'] : ['#f59e0b'],
        });

        toast.success('Голос учтён! ✓');

        // Анимация появления результатов
        setShowResults(true);
        
        // Конфетти с задержкой
        setTimeout(() => {
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
            colors: variant === 'A' ? ['#3b82f6'] : ['#f59e0b'],
          });
        }, 500);
        
        // Анимация прогресс-баров от 0 до финального значения
        const targetA = data.effect.percentA;
        const targetB = data.effect.percentB;
        setProgressA(0);
        setProgressB(0);
        
        const duration = 800; // 0.8s
        const steps = 60;
        const stepDuration = duration / steps;
        let currentStep = 0;

        const animateProgress = () => {
          if (currentStep <= steps) {
            const progress = currentStep / steps;
            const easeOut = 1 - Math.pow(1 - progress, 3); // ease-out cubic
            setProgressA(targetA * easeOut);
            setProgressB(targetB * easeOut);
            currentStep++;
            setTimeout(animateProgress, stepDuration);
          } else {
            setProgressA(targetA);
            setProgressB(targetB);
          }
        };

        // Небольшая задержка перед началом анимации
        setTimeout(() => {
          animateProgress();
        }, 100);
      } else {
        toast.error('Что-то пошло не так. Попробуйте снова');
      }
    } catch (error) {
      console.error('Ошибка при голосовании:', error);
      toast.error('Что-то пошло не так. Попробуйте снова');
    } finally {
      setIsVoting(false);
    }
  };

  // Навигация
  const currentIndex = allEffects.findIndex((e) => e.id === id);
  const prevEffect = currentIndex > 0 ? allEffects[currentIndex - 1] : null;
  const nextEffect = currentIndex < allEffects.length - 1 ? allEffects[currentIndex + 1] : null;

  const handleRandomEffect = async () => {
    try {
      const response = await fetch('/api/random-effect');
      if (response.ok) {
        const data = await response.json();
        router.push(`/effect/${data.id}`);
      }
    } catch (error) {
      console.error('Ошибка загрузки случайного эффекта:', error);
    }
  };

  if (loading) {
    return (
      <main id="main-content" className="min-h-screen bg-dark py-16 px-4" role="main">
        <div className="max-w-4xl mx-auto">
          {/* Скелетон заголовка */}
          <div className="mb-12">
            <Skeleton className="w-16 h-6 mb-4" variant="text" />
            <Skeleton className="w-3/4 h-12 mx-auto mb-4" variant="rectangular" />
          </div>
          
          {/* Скелетон вопроса */}
          <Skeleton className="w-full h-8 mb-12" variant="text" />
          
          {/* Скелетоны вариантов */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-8">
            <div className="bg-darkCard p-8 rounded-xl">
              <Skeleton className="w-24 h-6 mb-4" variant="text" />
              <Skeleton className="w-full h-20 mb-6" variant="rectangular" />
              <Skeleton className="w-full h-12" variant="rectangular" />
            </div>
            <div className="bg-darkCard p-8 rounded-xl">
              <Skeleton className="w-24 h-6 mb-4" variant="text" />
              <Skeleton className="w-full h-20 mb-6" variant="rectangular" />
              <Skeleton className="w-full h-12" variant="rectangular" />
            </div>
          </div>
        </div>
      </main>
    );
  }

  if (!effect) {
    return (
      <main id="main-content" className="min-h-screen bg-dark py-16 px-4" role="main">
        <div className="max-w-4xl mx-auto text-center text-light/60">
          <p className="text-lg mb-4">Эффект не найден</p>
          <Link href="/catalog" className="text-primary hover:text-secondary transition-colors">
            Вернуться в каталог
          </Link>
        </div>
      </main>
    );
  }

  if (!effect) {
    return null;
  }

  // Вычисляем проценты только если есть выбранный вариант
  const userPercent = hasVoted && selectedVariant ? (selectedVariant === 'A' ? effect.percentA : effect.percentB) : 0;
  const otherPercent = hasVoted && selectedVariant ? (selectedVariant === 'A' ? effect.percentB : effect.percentA) : 0;

  return (
    <main id="main-content" className="min-h-screen bg-dark py-16 px-4" role="main">
      <div className="max-w-4xl mx-auto">
        {/* Хлебные крошки */}
        <nav className="mb-8 text-sm text-light/60">
          <Link href="/" className="hover:text-light transition-colors">
            Главная
          </Link>
          <span className="mx-2">/</span>
          <Link
            href={`/catalog?category=${effect.category}`}
            className="hover:text-light transition-colors"
          >
            {effect.categoryName}
          </Link>
          <span className="mx-2">/</span>
          <span className="text-light">{effect.title}</span>
        </nav>

        {/* Заголовок */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-2xl">{effect.categoryEmoji}</span>
            <span className="text-sm text-light/60">{effect.categoryName}</span>
          </div>
          <h1
            className="text-4xl md:text-5xl font-bold mb-12 text-center"
            style={{
              background: 'linear-gradient(to right, #3b82f6, #f59e0b)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            {effect.title}
          </h1>
        </div>

        {/* Вопрос */}
        <p className="text-2xl md:text-3xl font-semibold text-center mb-12 text-light">
          {effect.question}
        </p>

        {/* Варианты - ВСЕГДА видны */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-8">
          {/* Вариант A */}
          <motion.div
            key={`variant-a-${effect.id}`}
            animate={votingVariant === 'A' ? {
              scale: [1, 1.05, 1],
            } : {}}
            transition={{ duration: 0.5 }}
            className={`group bg-darkCard p-8 rounded-xl hover:-translate-y-1 transition-all duration-300 border-2 ${
              selectedVariant === 'A' 
                ? 'border-primary bg-primary/10' 
                : votingVariant === 'A'
                ? 'border-primary bg-primary/10'
                : 'border-transparent'
            }`}
          >
            <h3 className="text-lg font-semibold text-light mb-4">Вариант А</h3>
            <p className="text-xl text-center text-light/90 mb-6">{effect.variantA}</p>
            
            {!hasVoted ? (
              <motion.button
                onClick={() => handleVote('A')}
                disabled={isVoting}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full mt-6 px-6 py-3 bg-dark rounded-lg text-light font-semibold hover:bg-gradient-to-r hover:from-primary hover:to-secondary transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isVoting && (
                  <svg
                    className="animate-spin h-5 w-5 text-light"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                )}
                {isVoting ? 'Отправка...' : 'Выбрать'}
              </motion.button>
            ) : (
              <div className="text-sm text-light/60 mt-6">
                {selectedVariant === 'A' && (
                  <span className="text-primary font-bold">✓ Ты выбрал этот вариант</span>
                )}
              </div>
            )}
          </motion.div>

          {/* Вариант B */}
          <motion.div
            key={`variant-b-${effect.id}`}
            animate={votingVariant === 'B' ? {
              scale: [1, 1.05, 1],
            } : {}}
            transition={{ duration: 0.5 }}
            className={`group bg-darkCard p-8 rounded-xl hover:-translate-y-1 transition-all duration-300 border-2 ${
              selectedVariant === 'B' 
                ? 'border-secondary bg-secondary/10' 
                : votingVariant === 'B'
                ? 'border-secondary bg-secondary/10'
                : 'border-transparent'
            }`}
          >
            <h3 className="text-lg font-semibold text-light mb-4">Вариант Б</h3>
            <p className="text-xl text-center text-light/90 mb-6">{effect.variantB}</p>
            
            {!hasVoted ? (
              <motion.button
                onClick={() => handleVote('B')}
                disabled={isVoting}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full mt-6 px-6 py-3 bg-dark rounded-lg text-light font-semibold hover:bg-gradient-to-r hover:from-primary hover:to-secondary transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isVoting && (
                  <svg
                    className="animate-spin h-5 w-5 text-light"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                )}
                {isVoting ? 'Отправка...' : 'Выбрать'}
              </motion.button>
            ) : (
              <div className="text-sm text-light/60 mt-6">
                {selectedVariant === 'B' && (
                  <span className="text-secondary font-bold">✓ Ты выбрал этот вариант</span>
                )}
              </div>
            )}
          </motion.div>
        </div>

        {/* Результаты - показываются ПОСЛЕ голосования */}
        {hasVoted && (
          <div className="mb-8">
            {/* Grid 2x1 (вертикально) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {/* Вариант A с результатами */}
              <div className={`bg-darkCard p-6 rounded-xl transition-all duration-300 ${
                selectedVariant === 'A' ? 'border-2 border-primary' : 'border-2 border-transparent'
              }`}>
                <h3 className="text-lg font-semibold text-light mb-3">
                  Вариант А
                </h3>
                <p className="text-light/80 mb-4">{effect.variantA}</p>
                
                {/* Прогресс-бар */}
                <div className="relative h-8 rounded-full bg-dark/50 overflow-hidden mb-3">
                  <div className="absolute inset-0 flex">
                    <motion.div
                      className="h-full bg-blue-500"
                      initial={{ width: 0 }}
                      animate={{ width: `${effect.percentA}%` }}
                      transition={{ duration: 1, delay: 0.3, ease: 'easeOut' }}
                    />
                    <motion.div
                      className="h-full bg-orange-500"
                      initial={{ width: 0 }}
                      animate={{ width: `${effect.percentB}%` }}
                      transition={{ duration: 1, delay: 0.3, ease: 'easeOut' }}
                    />
                  </div>
                </div>
                
                {/* Статистика */}
                <div className="flex items-center justify-between text-sm">
                  <span className="text-blue-400 font-medium">
                    <AnimatedCounter value={effect.percentA} decimals={1} suffix="%" />
                    <span className="text-light/40 ml-1">({effect.votesA})</span>
                  </span>
                  <span className="text-orange-400 font-medium">
                    <AnimatedCounter value={effect.percentB} decimals={1} suffix="%" />
                    <span className="text-light/40 ml-1">({effect.votesB})</span>
                  </span>
                </div>
                
                {selectedVariant === 'A' && (
                  <div className="mt-3 text-sm text-primary font-bold">
                    ✓ Ты выбрал этот вариант
                  </div>
                )}
              </div>

              {/* Вариант B с результатами */}
              <div className={`bg-darkCard p-6 rounded-xl transition-all duration-300 ${
                selectedVariant === 'B' ? 'border-2 border-secondary' : 'border-2 border-transparent'
              }`}>
                <h3 className="text-lg font-semibold text-light mb-3">
                  Вариант Б
                </h3>
                <p className="text-light/80 mb-4">{effect.variantB}</p>
                
                {/* Прогресс-бар */}
                <div className="relative h-8 rounded-full bg-dark/50 overflow-hidden mb-3">
                  <div className="absolute inset-0 flex">
                    <motion.div
                      className="h-full bg-blue-500"
                      initial={{ width: 0 }}
                      animate={{ width: `${effect.percentA}%` }}
                      transition={{ duration: 1, delay: 0.3, ease: 'easeOut' }}
                    />
                    <motion.div
                      className="h-full bg-orange-500"
                      initial={{ width: 0 }}
                      animate={{ width: `${effect.percentB}%` }}
                      transition={{ duration: 1, delay: 0.3, ease: 'easeOut' }}
                    />
                  </div>
                </div>
                
                {/* Статистика */}
                <div className="flex items-center justify-between text-sm">
                  <span className="text-blue-400 font-medium">
                    <AnimatedCounter value={effect.percentA} decimals={1} suffix="%" />
                    <span className="text-light/40 ml-1">({effect.votesA})</span>
                  </span>
                  <span className="text-orange-400 font-medium">
                    <AnimatedCounter value={effect.percentB} decimals={1} suffix="%" />
                    <span className="text-light/40 ml-1">({effect.votesB})</span>
                  </span>
                </div>
                
                {selectedVariant === 'B' && (
                  <div className="mt-3 text-sm text-secondary font-bold">
                    ✓ Ты выбрал этот вариант
                  </div>
                )}
              </div>
            </div>

            {/* Сообщение после голосования */}
            <motion.div 
              className="mt-8 p-6 bg-darkCard/50 rounded-xl border border-light/10"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
                <div className="flex items-start justify-between mb-3">
                  <p className="text-light/80">
                    Вы выбрали: <span className="font-bold text-light">{selectedVariant === 'A' ? 'Вариант А' : 'Вариант Б'}</span>
                  </p>
                  <AnimatePresence>
                    {selectedVariant && (() => {
                      const isInMajority =
                        selectedVariant === 'A'
                          ? effect.votesA > effect.votesB
                          : effect.votesB > effect.votesA;

                      if (isInMajority) {
                        return (
                          <motion.div 
                            className="px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap bg-primary/20 border border-primary/50 text-primary"
                            initial={{ scale: 0, rotate: -180 }}
                            animate={{ scale: 1, rotate: 0 }}
                            transition={{ 
                              type: 'spring', 
                              stiffness: 200, 
                              damping: 15,
                              delay: 1.2 
                            }}
                          >
                            <motion.span
                              initial={{ scale: 0 }}
                              animate={{ scale: [1, 1.2, 1] }}
                              transition={{ 
                                duration: 0.5, 
                                delay: 1.4,
                                times: [0, 0.5, 1]
                              }}
                            >
                              👥
                            </motion.span>
                            {' '}В большинстве
                          </motion.div>
                        );
                      } else {
                        return (
                          <motion.div 
                            className="px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap bg-secondary/20 border border-secondary/50 text-secondary"
                            initial={{ scale: 0, rotate: -180 }}
                            animate={{ scale: 1, rotate: 0 }}
                            transition={{ 
                              type: 'spring', 
                              stiffness: 200, 
                              damping: 15,
                              delay: 1.2 
                            }}
                          >
                            <motion.span
                              initial={{ scale: 0 }}
                              animate={{ scale: [1, 1.2, 1] }}
                              transition={{ 
                                duration: 0.5, 
                                delay: 1.4,
                                times: [0, 0.5, 1]
                              }}
                            >
                              ✨
                            </motion.span>
                            {' '}В меньшинстве
                          </motion.div>
                        );
                      }
                    })()}
                  </AnimatePresence>
                </div>
                <p className="text-light/70 text-sm mb-1">
                  Так же помнят <span className="text-primary font-semibold"><AnimatedCounter value={userPercent} decimals={1} suffix="%" /></span> участников
                </p>
                <p className="text-light/60 text-sm">
                  Другие <span className="text-orange-400 font-semibold"><AnimatedCounter value={100 - userPercent} decimals={1} suffix="%" /></span> помнят иначе - и это нормально.
                </p>
                <p className="text-light/50 text-sm mt-2">
                  Память у всех работает по-разному.
                </p>
              </motion.div>
          </div>
        )}

            {/* Текущее состояние (accordion) */}
            {effect.currentState && (
              <div className="mt-8 mb-8">
                <AccordionButton
                  title="Показать текущее состояние"
                  icon="🔍"
                  isOpen={isAccordionOpen}
                  onClick={() => setIsAccordionOpen(!isAccordionOpen)}
                />
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    isAccordionOpen ? 'max-h-96 mt-4' : 'max-h-0'
                  }`}
                >
                  <div className="bg-darkCard/50 p-6 rounded-xl">
                    <p className="text-light/80 mb-4">{effect.currentState}</p>
                    {effect.sourceLink && (
                      <a
                        href={effect.sourceLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:text-secondary transition-colors inline-flex items-center gap-2"
                      >
                        Источник
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                          />
                        </svg>
                      </a>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Интерпретации */}
            <div className="mt-8 mb-8">
              {effect.interpretations ? (
                <>
                  <AccordionButton
                    title="Что об этом говорят"
                    icon="📚"
                    isOpen={showInterpretations}
                    onClick={() => setShowInterpretations(!showInterpretations)}
                  />
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      showInterpretations ? 'max-h-[1000px] mt-4' : 'max-h-0'
                    }`}
                  >
                    <div className="space-y-4">
                      {/* Научное объяснение */}
                      <div className="p-6 bg-blue-500/10 border-l-4 border-blue-500 rounded-lg">
                        <h3 className="text-xl font-bold text-light mb-3 flex items-center gap-2">
                          🔬 Научное объяснение
                        </h3>
                        <p className="text-light/90 mb-4 leading-relaxed">
                          {effect.interpretations.scientific}
                        </p>
                        {effect.interpretations.scientificTheory && (
                          <p className="text-sm text-light/70 mb-2">
                            📖 Теория: <span className="font-semibold">{effect.interpretations.scientificTheory}</span>
                          </p>
                        )}
                        {effect.interpretations.scientificSource && (
                          <p className="text-sm text-light/70">
                            🔗 Источник: <a 
                              href={getSourceUrl(effect.interpretations.scientificSource)} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="font-semibold text-blue-400 hover:text-blue-300 underline transition-colors"
                            >
                              {effect.interpretations.scientificSource}
                            </a>
                          </p>
                        )}
                      </div>

                      {/* Версия сообществ */}
                      <div className="p-6 bg-orange-500/10 border-l-4 border-orange-500 rounded-lg">
                        <h3 className="text-xl font-bold text-light mb-3 flex items-center gap-2">
                          🌐 Версия сообществ
                        </h3>
                        <p className="text-light/90 mb-4 leading-relaxed">
                          {effect.interpretations.community}
                        </p>
                        {effect.interpretations.communitySource && (
                          <p className="text-sm text-light/70">
                            🔗 Источник: <a 
                              href={getSourceUrl(effect.interpretations.communitySource)} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="font-semibold text-orange-400 hover:text-orange-300 underline transition-colors"
                            >
                              {effect.interpretations.communitySource}
                            </a>
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="p-6 bg-darkCard/30 rounded-xl border border-light/10 text-center">
                  <div className="max-w-md mx-auto">
                    <p className="text-2xl mb-3">💭</p>
                    <p className="text-light/60 mb-3">
                      Интерпретации для этого эффекта пока не добавлены
                    </p>
                    <p className="text-light/80 text-sm mb-4">
                      Знаете научное объяснение или интересную версию сообществ? 
                      Помогите другим пользователям разобраться!
                    </p>
                    <button 
                      onClick={() => window.location.href = '/submit'}
                      className="px-6 py-2 bg-primary hover:bg-primary/80 text-light rounded-lg transition-colors font-medium"
                    >
                      Предложить интерпретацию
                    </button>
                  </div>
                </div>
              )}
            </div>

        {/* Навигация */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-8 border-t border-darkCard">
          <button
            onClick={() => prevEffect && router.push(`/effect/${prevEffect.id}`)}
            disabled={!prevEffect}
            className={`px-6 py-3 rounded-lg font-semibold transition-all ${
              prevEffect
                ? 'bg-darkCard text-light hover:bg-darkCard/80'
                : 'bg-darkCard/30 text-light/40 cursor-not-allowed'
            }`}
          >
            ← Предыдущий эффект
          </button>

          <button
            onClick={handleRandomEffect}
            className="px-6 py-3 rounded-lg font-semibold bg-darkCard text-light hover:bg-darkCard/80 transition-all"
          >
            🎲 Случайный
          </button>

          <button
            onClick={() => nextEffect && router.push(`/effect/${nextEffect.id}`)}
            disabled={!nextEffect}
            className={`px-6 py-3 rounded-lg font-semibold transition-all ${
              nextEffect
                ? 'bg-darkCard text-light hover:bg-darkCard/80'
                : 'bg-darkCard/30 text-light/40 cursor-not-allowed'
            }`}
          >
            Следующий эффект →
          </button>
        </div>
      </div>
    </main>
  );
}
