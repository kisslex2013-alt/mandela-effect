# 🚀 Langfuse Prompt Management - Быстрый старт

## ✅ Что уже сделано

1. ✅ Пакет `@meltstudio/langfuse-mcp-server` установлен глобально
2. ✅ Конфигурация добавлена в `C:\Users\kissl\.cursor\mcp.json`
3. ✅ Public Key настроен: `pk-lf-131807d7-2b95-41bb-9812-1a685eda55d2`

## ⚠️ Что нужно сделать СЕЙЧАС

### Шаг 1: Получить Secret Key из Langfuse

1. Откройте [Langfuse Cloud](https://cloud.langfuse.com)
2. Войдите в свой проект
3. Перейдите в **Settings → API Keys**
4. Найдите **Secret Key** (начинается с `sk-lf-...`)
5. Скопируйте его

### Шаг 2: Добавить Secret Key в переменные окружения

**PowerShell (постоянно):**
```powershell
[System.Environment]::SetEnvironmentVariable('LANGFUSE_SECRET_KEY', 'sk-lf-ваш-секретный-ключ', 'User')
```

**Или через GUI:**
1. Win + R → `sysdm.cpl` → Advanced → Environment Variables
2. User variables → New
3. Variable: `LANGFUSE_SECRET_KEY`
4. Value: ваш секретный ключ

### Шаг 3: Перезапустить Cursor

**Обязательно перезапустите Cursor** после добавления переменной окружения.

### Шаг 4: Проверить работу

1. Settings → MCP → Installed MCP Servers
2. Проверьте что `langfuse` подключен (зеленый статус)
3. В Cursor чате: `Покажи мне все мои промпты из Langfuse`

## 📚 Подробная документация

См. `docs/mcp/LANGFUSE_SETUP.md` для полной инструкции.

---

**Важно:** Без `LANGFUSE_SECRET_KEY` сервер не будет работать!

