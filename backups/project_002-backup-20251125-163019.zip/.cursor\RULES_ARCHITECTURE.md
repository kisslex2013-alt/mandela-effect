# Архитектура правил Cursor: Трехуровневая система

## 📊 Обзор уровней

### Level 1: Глобальные правила пользователя (User Rules)

- **Где**: Настройки Cursor (не в проекте)
- **Размер**: До 50 строк
- **Эффективность**: ⚠️ Низкая (загружается всегда)
- **Содержимое**: Только стиль общения и универсальные предпочтения

### Level 2: Проектные правила (Project Rules)

- **Где**: `.cursor/index.mdc` с `alwaysApply: true`
- **Размер**: До 100 строк
- **Эффективность**: ✅ Средняя (загружается для всех задач проекта)
- **Содержимое**: Стандарты проекта, архитектура, структура

### Level 3: Context-Aware правила

- **Где**: `.cursor/rules/*.mdc` с `globs` и `alwaysApply: false`
- **Размер**: Без ограничений (но лучше разбивать по доменам)
- **Эффективность**: ✅✅ Высокая (активируется только при релевантности)
- **Содержимое**: Специализированные правила для конкретных доменов

## 🎯 Принципы использования

### ✅ DO (Делай так)

**Level 1:**

- Только стиль общения ("Отвечай кратко")
- Language preferences
- Универсальные предпочтения кода

**Level 2:**

- Стандарты проекта (TypeScript, React версии)
- Структура проекта
- Маршрутизация агентов
- Общие принципы для команды

**Level 3:**

- Специализированные паттерны (API routes, компоненты, тесты)
- Доменные правила (database, auth, payments)
- Workflows для конкретных задач

### ❌ DON'T (Не делай так)

**Level 1:**

- ❌ Проектные стандарты
- ❌ Специфичные правила
- ❌ Больше 50 строк

**Level 2:**

- ❌ Специализированные паттерны (это Level 3)
- ❌ Больше 100 строк (разбивай на Level 3)
- ❌ Правила для конкретных файлов (используй globs)

**Level 3:**

- ❌ `alwaysApply: true` (это Level 2)
- ❌ Правила без `globs` (будут загружаться всегда)

## 📁 Структура файлов

```
.cursor/
├── index.mdc                    # Level 2: Проектные стандарты
├── LEVEL1_TEMPLATE.md           # Шаблон для Level 1
├── RULES_ARCHITECTURE.md        # Эта документация
├── MCP_SECURITY.md              # Безопасность MCP
└── rules/
    ├── 001-project-orchestrator.mdc  # DEPRECATED
    ├── agents/
    │   ├── backend-agent.mdc    # Level 3: globs: src/api/**/*
    │   ├── frontend-agent.mdc   # Level 3: globs: src/components/**/*
    │   └── testing-agent.mdc    # Level 3: globs: **/*.test.ts
    └── workflows/
        ├── feature-development.mdc
        └── code-review.mdc
```

## 🔍 Примеры Level 3 правил

### Правило для API интеграций

```markdown
---
description: API интеграции и внешние сервисы
globs:
  - src/api/integrations/**/*
  - src/services/external/**/*
alwaysApply: false
---

# API Integration Rules

...
```

### Правило для работы с БД

```markdown
---
description: Работа с базой данных
globs:
  - src/models/**/*
  - src/lib/db/**/*
  - prisma/**/*
alwaysApply: false
---

# Database Rules

...
```

### Правило для форм

```markdown
---
description: Формы и валидация
globs:
  - src/components/**/*Form*.tsx
  - src/components/**/*Form*.ts
alwaysApply: false
---

# Form Rules

...
```

## 📈 Оптимизация производительности

### Как уменьшить загрузку правил:

1. **Минимизируй Level 1** - только самое необходимое
2. **Держи Level 2 под 100 строк** - разбивай на Level 3 если нужно
3. **Используй точные globs** в Level 3:
   - ✅ `src/api/**/*` - хорошо
   - ❌ `**/*` - плохо (загрузится везде)
4. **Группируй по доменам** - один файл на домен

## 🚀 Миграция существующих правил

Если у тебя есть большой файл с `alwaysApply: true`:

1. Оставь в Level 2 только общие стандарты (до 100 строк)
2. Вынеси специализированные правила в Level 3 с globs
3. Обнови ссылки в других файлах

## ✅ Чеклист настройки

- [ ] Level 1 настроен в Cursor Settings (до 50 строк)
- [ ] Level 2 создан (`.cursor/index.mdc` с `alwaysApply: true`, до 100 строк)
- [ ] Level 3 правила имеют `globs` и `alwaysApply: false`
- [ ] Все ссылки обновлены на новые файлы
- [ ] Старые файлы помечены как DEPRECATED
