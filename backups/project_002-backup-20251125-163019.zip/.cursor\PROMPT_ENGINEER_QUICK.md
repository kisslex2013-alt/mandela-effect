# Prompt Engineer MCP - Краткая инструкция

## ✅ Установлено

Сервер установлен в `C:\Temp\prompt-engineer-mcp-server` и настроен в `mcp.json`.

## 🔑 Настройка API ключа (ОБЯЗАТЕЛЬНО)

### Получить ключ:

1. [console.anthropic.com](https://console.anthropic.com) → Settings → API Keys
2. Создайте ключ (начинается с `sk-ant-...`)

### Установить в Windows:

**PowerShell (постоянно):**

```powershell
[System.Environment]::SetEnvironmentVariable('ANTHROPIC_API_KEY', 'sk-ant-your-key', 'User')
```

**Или через GUI:**

- Win + R → `sysdm.cpl` → Advanced → Environment Variables
- User variables → New → `ANTHROPIC_API_KEY` = ваш ключ

### Перезапустить Cursor

После установки переменной **обязательно перезапустите Cursor**.

## 🚀 Использование

### В Cursor чате:

```
Используй prompt-engineer чтобы переписать промпт:
"Создай функцию для валидации email"
Язык: typescript
```

### Инструмент: `rewrite_coding_prompt`

**Параметры:**

- `prompt` - ваш исходный промпт
- `language` - язык (typescript, javascript, python, и т.д.)

## ✅ Проверка

1. Settings → MCP → Installed MCP Servers
2. `prompt-engineer` должен быть зеленым
3. Settings → MCP → Available Tools
4. Должен быть `rewrite_coding_prompt`

## ⚠️ Важно

- **Требуется Anthropic API ключ** - без него не работает
- **Использует Claude 3 Sonnet** - списываются токены
- **Лимит 40 инструментов** - проверьте общее количество

## 📝 Быстрая проверка ключа

```powershell
echo $env:ANTHROPIC_API_KEY
```

Если пусто - установите ключ и перезапустите Cursor.
