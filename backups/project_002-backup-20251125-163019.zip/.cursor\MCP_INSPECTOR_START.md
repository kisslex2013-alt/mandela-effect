# Как правильно запустить MCP Inspector

## Проблема

MCP Inspector не запускается в фоновом режиме — ему нужен интерактивный терминал.

## ✅ Правильный способ запуска

### Шаг 1: Откройте новый терминал

В Cursor:

- `Ctrl + Shift + `` (обратная кавычка) для нового терминала
- Или Terminal → New Terminal

### Шаг 2: Запустите Inspector

**Для Sequential Thinking:**

```powershell
npx -y @modelcontextprotocol/inspector npx -y @modelcontextprotocol/server-sequential-thinking
```

**Для Context7:**

```powershell
npx -y @modelcontextprotocol/inspector npx -y @upstash/context7-mcp --api-key YOUR_API_KEY
```

**Для Filesystem:**

```powershell
npx -y @modelcontextprotocol/inspector npx -y @modelcontextprotocol/server-filesystem ./src ./public
```

**Для Memory:**

```powershell
npx -y @modelcontextprotocol/inspector npx -y @modelcontextprotocol/server-memory
```

**Для GitHub:**

```powershell
$env:GITHUB_PERSONAL_ACCESS_TOKEN="your_token"; npx -y @modelcontextprotocol/inspector npx -y @modelcontextprotocol/server-github
```

### Шаг 3: Дождитесь запуска

Вы увидите:

```
Starting MCP inspector...
MCP Inspector running on http://localhost:6277
Opening browser...
```

### Шаг 4: Откройте браузер

Inspector автоматически откроет браузер, или откройте вручную:

- `http://localhost:6277`

## ⚠️ Важно

1. **Не закрывайте терминал** — Inspector должен работать пока вы тестируете
2. **Оставьте терминал открытым** — при закрытии Inspector остановится
3. **Один Inspector на порт** — если порт занят, завершите предыдущий процесс

## 🔧 Если порт занят

**Найти процесс:**

```powershell
netstat -ano | findstr :6277
```

**Завершить процесс (замените PID):**

```powershell
taskkill /PID <PID> /F
```

**Или использовать другой порт:**

```powershell
$env:MCP_INSPECTOR_PORT=6278
npx -y @modelcontextprotocol/inspector npx -y @modelcontextprotocol/server-sequential-thinking
```

## 🎯 Альтернатива: Тестирование через Cursor

Если Inspector вызывает проблемы, можно тестировать серверы напрямую через Cursor:

1. ✅ Убедитесь что серверы настроены в `mcp.json` (уже сделано)
2. Перезапустите Cursor
3. Проверьте в **Settings → MCP → Installed MCP Servers**
4. Убедитесь что нет ошибок подключения
5. Проверьте доступные инструменты в **Settings → MCP → Available Tools**

Этот способ проще и не требует запуска Inspector отдельно.

## 📋 Быстрая проверка всех серверов

**В Cursor:**

1. Settings → MCP → Installed MCP Servers
2. Проверьте статус каждого сервера:
   - ✅ Зеленый = работает
   - ❌ Красный = ошибка
   - ⚠️ Желтый = предупреждение

**Если сервер не работает:**

- Проверьте логи в Output панели
- Убедитесь что API ключи/токены правильные
- Проверьте что пакеты установлены (`npx` должен их скачать автоматически)

## 💡 Рекомендация

Для большинства случаев **не нужно запускать Inspector отдельно**. Cursor автоматически подключает MCP серверы при запуске. Просто:

1. Настройте `mcp.json` (уже сделано ✅)
2. Перезапустите Cursor
3. Проверьте статус в Settings → MCP

Inspector нужен только для глубокой отладки проблем подключения.
