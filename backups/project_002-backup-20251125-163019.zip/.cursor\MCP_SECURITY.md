# MCP Security Best Practices

## 🔒 Защита секретов

### Файл `.cursor/mcp.json`

**⚠️ ВАЖНО:** Файл `.cursor/mcp.json` содержит секретные данные:

- API ключи (Context7, GitHub и др.)
- Токены доступа
- Персональные данные

**Этот файл НЕ должен попадать в Git репозиторий!**

### Что сделано:

1. ✅ `.cursor/mcp.json` добавлен в `.gitignore`
2. ✅ Создан шаблон `.cursor/mcp.json.example` без секретов
3. ✅ Filesystem MCP настроен с ограниченным доступом

## 📁 Ограничение доступа Filesystem MCP

### Текущая конфигурация:

```json
"filesystem": {
  "command": "npx",
  "args": [
    "-y",
    "@modelcontextprotocol/server-filesystem",
    "${workspaceFolder}/src:ro",
    "${workspaceFolder}/public:ro"
  ]
}
```

### Что это означает:

- ✅ Доступ только к `src/` и `public/` директориям
- ✅ Read-only доступ (`:ro`) - MCP не может изменять файлы
- ❌ Нет доступа к корню проекта
- ❌ Нет доступа к `.cursor/`, `.git/`, `node_modules/` и другим системным папкам

### Если нужен write доступ:

Замени `:ro` на обычный путь (только если действительно нужно):

```json
"${workspaceFolder}/src" // write access
```

⚠️ **Рекомендуется использовать read-only доступ везде, где возможно!**

## 🚀 Настройка для нового проекта

1. Скопируй `.cursor/mcp.json.example` в `.cursor/mcp.json`
2. Замени плейсхолдеры на реальные значения:
   - `YOUR_CONTEXT7_API_KEY_HERE` → твой Context7 API ключ
   - `YOUR_GITHUB_TOKEN_HERE` → твой GitHub токен
3. Настрой пути для filesystem под свой проект

## 📝 Проверка безопасности

Перед коммитом в Git проверь:

```bash
# Проверь, что mcp.json не попадет в git
git status

# Убедись, что .gitignore работает
git check-ignore .cursor/mcp.json
```

## 🔐 Дополнительные меры безопасности

1. **Используй переменные окружения** для секретов (если поддерживается)
2. **Регулярно ротируй токены** (особенно GitHub PAT)
3. **Ограничивай права токенов** (минимальные необходимые права)
4. **Не делись mcp.json** даже в приватных репозиториях
5. **Используй read-only доступ** для filesystem где возможно
