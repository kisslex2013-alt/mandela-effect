# Ручные действия для завершения оптимизации

## 🔴 Критически важно (сделать сейчас)

### 1. Отключить Memories ✅ ВЫПОЛНЕНО

**Действие:** Settings → Features → Memories → Отключить

**Экономия:** 40-50% токенов

**Почему:** Memories добавляет 4000+ токенов к каждому запросу, вставляя всю историю чатов.

**Статус:** ✅ Выполнено пользователем

### 2. Отключить Auto режим ✅ ВЫПОЛНЕНО

**Действие:** Settings → Model → Отключить Auto режим

**Почему:**

- Потеря контекста при смене модели
- Непредсказуемое поведение
- Нет прозрачности какая модель используется

**Вместо этого:** Выбирайте модели вручную:

- Простые задачи → Gemini Flash / Cursor Small (бесплатно)
- Сложная отладка → Claude Sonnet (premium)
- Архитектура → Claude Sonnet (premium)

**Статус:** ✅ Выполнено пользователем

## 🟡 Важно (сделать сегодня)

### 3. Протестировать MCP серверы ✅ ВЫПОЛНЕНО

**Команды для тестирования:**

```bash
# Sequential Thinking
npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-sequential-thinking

# Context7
npx @modelcontextprotocol/inspector npx @upstash/context7-mcp --api-key YOUR_KEY

# Filesystem
npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-filesystem ./src ./public

# Memory
npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-memory

# GitHub
npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-github
```

**Проверка в Cursor:**

- Settings → MCP → Available Tools
- Убедитесь что все серверы подключены
- Проверьте количество инструментов (лимит 40)

**Статус:** ✅ Выполнено пользователем

### 4. Проверить наличие старых .cursorrules ✅ ВЫПОЛНЕНО

**Действие:** Проверьте корень проекта на наличие `.cursorrules` файла

**Если найден:**

1. Создайте backup: `cp .cursorrules .cursorrules.backup`
2. Удалите файл после проверки миграции

**Статус:** ✅ Выполнено пользователем (старые файлы не найдены или уже удалены)

## 🟢 При инициализации проекта

### 5. Настроить Vite конфигурацию ✅ ВЫПОЛНЕНО

**Когда:** При создании проекта с Vite

**Действие:**

1. Скопируйте `vite.config.ts.example` в `vite.config.ts`
2. Установите зависимости: `npm install -D vite @vitejs/plugin-react`
3. Настройте алиасы под структуру проекта

**Статус:** ✅ Выполнено автоматически

**Что сделано:**

- ✅ Добавлены алиасы в существующий `vite.config.js`:
  - `@` → `./src`
  - `@components` → `./src/components`
  - `@store` → `./src/store`
  - `@hooks` → `./src/hooks`
  - `@utils` → `./src/utils`
  - `@constants` → `./src/constants`
  - `@styles` → `./src/styles`

**Manual chunks уже настроены в vite.config.js:**

- react-vendor (react, react-dom, recharts, framer-motion, zustand и др.)
- icons-vendor (lucide-react)
- tone-vendor (tone.js)
- date-vendor (date-fns)

**Использование алиасов:**
Теперь можно использовать в коде:

```javascript
// Вместо
import { Button } from '../../../components/ui/Button'

// Можно писать
import { Button } from '@components/ui/Button'
import { useStore } from '@store/useEntriesStore'
import { formatDate } from '@utils/formatting'
```

## 📋 Регулярные действия

### Еженедельно

- [ ] Проверять token usage в cursor.com/dashboard → Usage tab
- [ ] Отслеживать daily burn rate
- [ ] Проверять model distribution

### Ежемесячно

- [ ] Очищать chat cache (Settings → Clear chat cache)
- [ ] Review правил - удалять неиспользуемые
- [ ] Обновлять документацию

### Каждые 2 месяца

- [ ] Полный review всех правил
- [ ] Оптимизация на основе metrics
- [ ] Эксперименты с новыми MCP servers

## ✅ Чеклист быстрой проверки

После выполнения всех действий проверьте:

- [x] Memories отключены ✅
- [x] Auto режим отключен ✅
- [x] Все MCP серверы работают (Settings → MCP) ✅
- [x] Context-aware правила активируются (проверьте при открытии файлов) ✅
- [x] .cursorignore работает (node_modules не индексируется) ✅
- [x] Filesystem доступ ограничен (только src/ и public/) ✅
- [x] Level 2 правила загружаются (.cursor/index.mdc) ✅
- [x] Vite алиасы настроены ✅

## 📊 Ожидаемая экономия

После выполнения всех действий:

- **Memories отключены:** -40-50% токенов
- **Context-aware правила:** -15-25% токенов
- **.cursorignore:** -10-15% токенов
- **Ручной выбор моделей:** -60-80% на простых задачах

**Суммарная экономия: 70-85% токенов**
