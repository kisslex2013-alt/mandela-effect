# 🔧 Устранение проблем с Langfuse MCP

## ❌ Проблема: "Покажи мне все мои промпты" не работает

### ✅ Решение 1: Проверьте подключение MCP сервера

1. **Откройте настройки Cursor:**
   - `Ctrl + ,` (или `Cmd + ,` на Mac)
   - Перейдите в **Settings → MCP → Installed MCP Servers**

2. **Проверьте статус `langfuse`:**
   - Должен быть **зеленый статус** (подключен)
   - Если красный/желтый — есть проблема с подключением

3. **Проверьте доступные инструменты:**
   - Settings → MCP → Available Tools
   - Должны быть: `list_prompts`, `get_prompt`, `compile_prompt`

### ✅ Решение 2: Перезапустите Cursor

**КРИТИЧНО:** После изменения `mcp.json` нужно **полностью перезапустить Cursor**:
1. Закройте все окна Cursor
2. Убедитесь, что процесс завершен (Task Manager)
3. Откройте Cursor заново

### ✅ Решение 3: Проверьте конфигурацию

Убедитесь, что в `C:\Users\kissl\.cursor\mcp.json` правильная конфигурация:

```json
{
  "mcpServers": {
    "langfuse": {
      "command": "melt-langfuse-mcp",
      "env": {
        "LANGFUSE_SECRET_KEY": "sk-lf-c39b521d-da6a-4ca7-9acf-441191d27e8f",
        "LANGFUSE_PUBLIC_KEY": "pk-lf-e9134736-a0ce-4a8d-bb94-f0e61054f67c"
      }
    }
  }
}
```

### ✅ Решение 4: Проверьте регион Langfuse

Если используете **EU регион**, добавьте в конфигурацию:

```json
{
  "mcpServers": {
    "langfuse": {
      "command": "melt-langfuse-mcp",
      "env": {
        "LANGFUSE_SECRET_KEY": "sk-lf-c39b521d-da6a-4ca7-9acf-441191d27e8f",
        "LANGFUSE_PUBLIC_KEY": "pk-lf-e9134736-a0ce-4a8d-bb94-f0e61054f67c",
        "LANGFUSE_HOST": "https://cloud.langfuse.com"
      }
    }
  }
}
```

### ✅ Решение 5: Альтернативный способ (Python SDK)

Если MCP не работает, используйте Python скрипт:

1. **Установите Langfuse SDK:**
   ```bash
   pip install langfuse
   ```

2. **Запустите скрипт:**
   ```bash
   python scripts/get-langfuse-prompts.py
   ```

### ✅ Решение 6: Проверьте логи Cursor

1. Откройте **Developer Tools** в Cursor:
   - `Ctrl + Shift + I` (или `Cmd + Option + I` на Mac)
   - Перейдите в **Console**

2. Ищите ошибки связанные с `langfuse` или `mcp`

### ✅ Решение 7: Проверьте версию MCP сервера

```bash
melt-langfuse-mcp --version
```

Должна быть версия **2.3.0** или выше.

Если версия устарела:
```bash
npm update -g @meltstudio/langfuse-mcp-server
```

## 📋 Чек-лист проверки

- [ ] Cursor полностью перезапущен после изменения конфигурации
- [ ] `melt-langfuse-mcp` установлен глобально (`npm install -g @meltstudio/langfuse-mcp-server`)
- [ ] В `mcp.json` правильные ключи (без `${...}` для прямых значений)
- [ ] В Settings → MCP → Installed MCP Servers `langfuse` показывает зеленый статус
- [ ] В Settings → MCP → Available Tools есть инструменты `list_prompts`, `get_prompt`, `compile_prompt`
- [ ] Промпты созданы в Langfuse dashboard
- [ ] Промпты имеют метку `production` (или настроена другая метка)

## 💡 Правильные команды в чате Cursor

После успешного подключения используйте:

- **"Покажи мне все мои промпты из Langfuse"**
- **"List my prompts"**
- **"Show me all prompts"**
- **"Получи промпт [название]"**
- **"Get the [prompt-name] prompt"**

## 🆘 Если ничего не помогает

1. Проверьте официальную документацию: [Langfuse MCP Server](https://github.com/MeltStudio/melt-langfuse-mcp)
2. Создайте issue в репозитории проекта
3. Проверьте логи Cursor в Developer Tools

---

**Последнее обновление:** 2025-01-27

