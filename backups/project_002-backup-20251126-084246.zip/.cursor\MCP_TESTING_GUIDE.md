# Руководство по тестированию MCP серверов

## ❌ Ошибка: "Failed to discover OAuth metadata"

Эта ошибка возникает, когда вы пытаетесь использовать OAuth для сервера, который его не поддерживает.

## ✅ Правильное тестирование MCP серверов

### 1. Sequential Thinking (НЕ требует OAuth)

**Команда для тестирования:**

```bash
npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-sequential-thinking
```

**Важно:** Этот сервер НЕ требует аутентификации. Просто запустите команду выше без OAuth настроек.

### 2. Context7 (Требует API ключ, НЕ OAuth)

**Команда для тестирования:**

```bash
npx @modelcontextprotocol/inspector npx @upstash/context7-mcp --api-key YOUR_API_KEY
```

**Где взять API ключ:**

- Зарегистрируйтесь на context7.com/dashboard
- Скопируйте API ключ из дашборда
- Используйте его в команде выше

**В MCP Inspector:**

- НЕ используйте OAuth
- Используйте "Command Line Arguments" или "Environment Variables"
- Добавьте `--api-key YOUR_KEY` в аргументы

### 3. Filesystem (НЕ требует аутентификации)

**Команда для тестирования:**

```bash
npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-filesystem ./src ./public
```

**Важно:** Просто укажите директории, которые нужно открыть.

### 4. Memory (НЕ требует OAuth)

**Команда для тестирования:**

```bash
npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-memory
```

**С переменной окружения:**

```bash
MEMORY_FILE_PATH=./.mcp-memory.json npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-memory
```

### 5. GitHub (Требует Personal Access Token, НЕ OAuth)

**Команда для тестирования:**

```bash
GITHUB_PERSONAL_ACCESS_TOKEN=your_token npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-github
```

**Где взять токен:**

- github.com/settings/tokens
- Создайте Personal Access Token (classic)
- Scope: `repo`, `read:user`

**В MCP Inspector:**

- Используйте "Environment Variables"
- Добавьте: `GITHUB_PERSONAL_ACCESS_TOKEN=your_token`
- НЕ используйте OAuth

## 🔧 Как правильно использовать MCP Inspector

### Шаг 1: Выберите метод аутентификации

**Для серверов БЕЗ аутентификации:**

- Выберите "No Authentication"
- Или просто запустите команду напрямую

**Для серверов с API ключами:**

- Используйте "Command Line Arguments"
- Добавьте `--api-key YOUR_KEY` в args
- ИЛИ используйте "Environment Variables"

**Для серверов с токенами:**

- Используйте "Environment Variables"
- Добавьте переменную: `TOKEN_NAME=your_token`

### Шаг 2: Укажите команду

**Формат:**

```
npx -y @package/name
```

**С аргументами:**

```
npx -y @package/name --arg1 value1 --arg2 value2
```

**С переменными окружения:**

```
VAR_NAME=value npx -y @package/name
```

## 📋 Чеклист тестирования

### Sequential Thinking

- [ ] Запустить без аутентификации
- [ ] Проверить доступные инструменты
- [ ] Протестировать базовые функции

### Context7

- [ ] Получить API ключ с context7.com/dashboard
- [ ] Запустить с `--api-key`
- [ ] Проверить доступ к документации

### Filesystem

- [ ] Указать директории (src, public)
- [ ] Проверить read/write доступ
- [ ] Убедиться что ограничения работают

### Memory

- [ ] Запустить без аутентификации
- [ ] Проверить создание .mcp-memory.json
- [ ] Протестировать сохранение/загрузку

### GitHub

- [ ] Создать Personal Access Token
- [ ] Запустить с переменной окружения
- [ ] Проверить доступ к репозиториям

## ⚠️ Частые ошибки

### ❌ Ошибка: "Failed to discover OAuth metadata"

**Причина:** Попытка использовать OAuth для сервера, который его не поддерживает.

**Решение:**

- Используйте "No Authentication" для серверов без аутентификации
- Используйте "Command Line Arguments" или "Environment Variables" для API ключей/токенов

### ❌ Ошибка: "Connection refused"

**Причина:** Сервер не запускается или неправильная команда.

**Решение:**

- Проверьте правильность команды `npx`
- Убедитесь что пакет существует в npm
- Проверьте интернет соединение

### ❌ Ошибка: "Invalid API key"

**Причина:** Неправильный или истекший API ключ.

**Решение:**

- Проверьте ключ в дашборде сервиса
- Убедитесь что используете правильный формат
- Проверьте что ключ не истек

## 🎯 Быстрый старт

**Для тестирования всех серверов сразу:**

```bash
# 1. Sequential Thinking (без аутентификации)
npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-sequential-thinking

# 2. Context7 (с API ключом)
npx @modelcontextprotocol/inspector npx @upstash/context7-mcp --api-key YOUR_CONTEXT7_KEY

# 3. Filesystem (с директориями)
npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-filesystem ./src ./public

# 4. Memory (без аутентификации)
npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-memory

# 5. GitHub (с токеном)
GITHUB_PERSONAL_ACCESS_TOKEN=your_token npx @modelcontextprotocol/inspector npx @modelcontextprotocol/server-github
```

## ✅ Проверка в Cursor

После тестирования проверьте в Cursor:

1. Settings → MCP → Installed MCP Servers
2. Убедитесь что все серверы подключены
3. Проверьте количество инструментов (лимит 40)
4. Проверьте что нет ошибок подключения
