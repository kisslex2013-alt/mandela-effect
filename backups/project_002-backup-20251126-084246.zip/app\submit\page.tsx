'use client';

import { useState, useEffect, FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import confetti from 'canvas-confetti';
import AccordionButton from '@/components/AccordionButton';
import EffectForm from '@/components/EffectForm';

interface Category {
  category: string;
  emoji: string;
  name: string;
  count: number;
}

interface FormData {
  category: string;
  title: string;
  question: string;
  variantA: string;
  variantB: string;
  currentState: string;
  sourceLink: string;
  email: string;
}

interface FormErrors {
  category?: string;
  title?: string;
  question?: string;
  variantA?: string;
  variantB?: string;
  sourceLink?: string;
}

export default function SubmitPage() {
  const router = useRouter();
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    category: '',
    title: '',
    question: '',
    variantA: '',
    variantB: '',
    currentState: '',
    sourceLink: '',
    email: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [interpretations, setInterpretations] = useState({
    scientific: '',
    scientificTheory: '',
    scientificSource: '',
    community: '',
    communitySource: '',
  });
  const [showInterpretations, setShowInterpretations] = useState(false);

  // Загружаем категории
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch('/api/categories');
        if (response.ok) {
          const data = await response.json();
          setCategories(data);
        }
      } catch (error) {
        console.error('Ошибка загрузки категорий:', error);
      }
    };
    fetchCategories();
  }, []);

  // Валидация URL
  const isValidUrl = (url: string): boolean => {
    if (!url.trim()) return true; // Пустой URL валиден (опциональное поле)
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  // Валидация поля
  const validateField = (name: keyof FormData, value: string): string | undefined => {
    switch (name) {
      case 'category':
        if (!value) return 'Это поле обязательно';
        break;
      case 'title':
        if (!value) return 'Это поле обязательно';
        if (value.length < 5) return 'Минимум 5 символов';
        break;
      case 'question':
        if (!value) return 'Это поле обязательно';
        if (value.length < 20) return 'Минимум 20 символов';
        break;
      case 'variantA':
        if (!value) return 'Это поле обязательно';
        if (value.length < 3) return 'Минимум 3 символа';
        break;
      case 'variantB':
        if (!value) return 'Это поле обязательно';
        if (value.length < 3) return 'Минимум 3 символа';
        if (value === formData.variantA) return 'Варианты должны быть разными';
        break;
      case 'sourceLink':
        if (value && !isValidUrl(value)) return 'Введите корректный URL';
        break;
      default:
        break;
    }
    return undefined;
  };

  // Обработка изменения поля
  const handleChange = (name: keyof FormData, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
    
    // Если поле было затронуто, валидируем его
    if (touched[name]) {
      const error = validateField(name, value);
      setErrors((prev) => ({ ...prev, [name]: error }));
    }

    // Специальная валидация для variantB при изменении variantA
    if (name === 'variantA' && touched.variantB) {
      const variantBError = validateField('variantB', formData.variantB);
      setErrors((prev) => ({ ...prev, variantB: variantBError }));
    }
  };

  // Обработка blur (потеря фокуса)
  const handleBlur = (name: keyof FormData) => {
    setTouched((prev) => ({ ...prev, [name]: true }));
    const error = validateField(name, formData[name as keyof FormData]);
    setErrors((prev) => ({ ...prev, [name]: error }));
  };

  // Проверка валидности всей формы
  const isFormValid = (): boolean => {
    return (
      !!formData.category &&
      !!formData.title &&
      formData.title.length >= 5 &&
      !!formData.question &&
      formData.question.length >= 20 &&
      !!formData.variantA &&
      formData.variantA.length >= 3 &&
      !!formData.variantB &&
      formData.variantB.length >= 3 &&
      formData.variantA !== formData.variantB &&
      (!formData.sourceLink || isValidUrl(formData.sourceLink)) &&
      Object.keys(errors).every((key) => !errors[key as keyof FormErrors])
    );
  };

  // Обработка отправки формы
  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // Помечаем все поля как затронутые
    const allTouched: Record<string, boolean> = {};
    Object.keys(formData).forEach((key) => {
      allTouched[key] = true;
    });
    setTouched(allTouched);

    // Валидируем все поля
    const newErrors: FormErrors = {};
    Object.keys(formData).forEach((key) => {
      const error = validateField(key as keyof FormData, formData[key as keyof FormData]);
      if (error) {
        newErrors[key as keyof FormErrors] = error;
      }
    });
    setErrors(newErrors);

    // Если есть ошибки, не отправляем
    if (Object.keys(newErrors).length > 0) {
      toast.error('Пожалуйста, исправьте ошибки в форме');
      return;
    }

    if (!isFormValid()) {
      toast.error('Пожалуйста, заполните все обязательные поля');
      return;
    }

    setIsLoading(true);

    try {
      // Подготовка данных эффекта
      const effectData: any = {
        ...formData,
      };

      // Добавляем интерпретации только если хотя бы одно поле заполнено
      const hasInterpretations = 
        interpretations.scientific.trim() || 
        interpretations.community.trim();

      if (hasInterpretations) {
        effectData.interpretations = {
          scientific: interpretations.scientific.trim(),
          scientificTheory: interpretations.scientificTheory.trim() || undefined,
          scientificSource: interpretations.scientificSource.trim() || undefined,
          community: interpretations.community.trim(),
          communitySource: interpretations.communitySource.trim() || undefined,
        };
      }

      const response = await fetch('/api/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(effectData),
      });

      // Проверяем что response.ok перед парсингом
      if (!response.ok) {
        // Пытаемся получить текст ошибки
        let errorMessage = `HTTP error! status: ${response.status}`;
        try {
          const errorData = await response.json();
          errorMessage = errorData.error || errorMessage;
        } catch {
          // Если не удалось распарсить JSON, используем текст
          const errorText = await response.text();
          errorMessage = errorText || errorMessage;
        }
        
        // Специальная обработка для rate limiting
        if (response.status === 429) {
          toast.error(errorMessage, { duration: 5000 });
        } else {
          toast.error(errorMessage);
        }
        
        throw new Error(errorMessage);
      }

      const data = await response.json();

      // Проверяем success в ответе
      if (!data.success) {
        throw new Error(data.error || 'Ошибка отправки формы');
      }

      // Успех!
      setIsSubmitted(true);
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#3b82f6', '#f59e0b'],
      });
      toast.success('Эффект отправлен на модерацию! ✓');

      // Очищаем форму
      setFormData({
        category: '',
        title: '',
        question: '',
        variantA: '',
        variantB: '',
        currentState: '',
        sourceLink: '',
        email: '',
      });
      setErrors({});
      setTouched({});
      // Сбросить интерпретации
      setInterpretations({
        scientific: '',
        scientificTheory: '',
        scientificSource: '',
        community: '',
        communitySource: '',
      });

      // Через 3 секунды сбрасываем состояние успеха
      setTimeout(() => {
        setIsSubmitted(false);
      }, 3000);
    } catch (error) {
      console.error('Ошибка отправки формы:', error);
      // Показываем toast только если его ещё не показали выше
      if (error instanceof Error && !error.message.includes('HTTP error')) {
        toast.error(error.message || 'Что-то пошло не так. Попробуйте снова');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main id="main-content" className="min-h-screen bg-dark pt-24 pb-16 px-4" role="main">
      <div className="max-w-2xl mx-auto">
        {/* Заголовок */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-light mb-2">Предложить новый эффект</h1>
          <p className="text-lg text-light/60">Помоги расширить коллекцию эффектов Манделы</p>
        </div>

        {/* Сообщение об успехе */}
        {isSubmitted && (
          <div className="bg-primary/20 border border-primary/50 rounded-xl p-6 mb-8 text-center">
            <div className="text-4xl mb-2">✅</div>
            <h3 className="text-xl font-semibold text-light mb-2">
              Спасибо! Эффект отправлен на модерацию
            </h3>
            <p className="text-light/80">Мы проверим его и добавим в каталог</p>
          </div>
        )}

        {/* Форма */}
        {!isSubmitted ? (
          <>
            <EffectForm
              onSubmit={async (data) => {
                setIsLoading(true);
                try {
                  // Подготовка данных для API
                  const effectData: any = {
                    category: data.category,
                    title: data.title,
                    question: data.question,
                    variantA: data.variantA,
                    variantB: data.variantB,
                    variantADescription: data.variantADescription,
                    variantBDescription: data.variantBDescription,
                    currentState: data.currentState,
                    sourceLink: data.sourceLink,
                    email: formData.email, // Сохраняем email из старой формы
                  };

                  // Добавляем интерпретации если есть
                  if (data.interpretations) {
                    effectData.interpretations = data.interpretations;
                  }

                  const response = await fetch('/api/submit', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(effectData),
                  });

                  if (!response.ok) {
                    let errorMessage = `HTTP error! status: ${response.status}`;
                    try {
                      const errorData = await response.json();
                      errorMessage = errorData.error || errorMessage;
                    } catch {
                      const errorText = await response.text();
                      errorMessage = errorText || errorMessage;
                    }
                    
                    if (response.status === 429) {
                      toast.error(errorMessage, { duration: 5000 });
                    } else {
                      toast.error(errorMessage);
                    }
                    throw new Error(errorMessage);
                  }

                  const responseData = await response.json();
                  if (!responseData.success) {
                    throw new Error(responseData.error || 'Ошибка отправки формы');
                  }

                  // Успех!
                  setIsSubmitted(true);
                  confetti({
                    particleCount: 100,
                    spread: 70,
                    origin: { y: 0.6 },
                    colors: ['#3b82f6', '#f59e0b'],
                  });
                  toast.success('Эффект отправлен на модерацию! ✓');
                  
                  // Через 3 секунды сбрасываем состояние успеха
                  setTimeout(() => {
                    setIsSubmitted(false);
                  }, 3000);
                } catch (error) {
                  console.error('Ошибка отправки формы:', error);
                  if (error instanceof Error && !error.message.includes('HTTP error')) {
                    toast.error(error.message || 'Что-то пошло не так. Попробуйте снова');
                  }
                  throw error;
                } finally {
                  setIsLoading(false);
                }
              }}
              submitButtonText="Отправить на модерацию"
            />
            
            {/* Email поле (оставляем отдельно) */}
            <div className="mb-8 max-w-[600px] mx-auto">
              <label htmlFor="email" className="block text-sm font-semibold mb-2 text-light">
                Ваш email
              </label>
              <input
                type="email"
                id="email"
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                placeholder="для связи (необязательно)"
                className="w-full p-3 rounded-lg bg-darkCard border border-light/20 text-light placeholder:text-light/40 focus:outline-none focus:border-primary transition-colors min-h-[44px]"
              />
              <p className="text-light/60 text-sm mt-1">Необязательное поле</p>
            </div>
          </>
        ) : null}
        
      </div>
    </main>
  );
}

